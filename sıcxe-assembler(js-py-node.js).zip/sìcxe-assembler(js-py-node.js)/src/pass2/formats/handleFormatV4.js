// Format v4 is being handled by the same code as v3, so we just
// call the v3 handler.
// This is not ideal, but v4 just requires a few diffrences (operand address)
