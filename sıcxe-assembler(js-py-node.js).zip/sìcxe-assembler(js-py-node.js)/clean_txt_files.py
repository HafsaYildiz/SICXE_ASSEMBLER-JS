import os

directory = './output'

for filename in os.listdir(directory):
    if filename.endswith(".txt"):
        filepath = os.path.join(directory, filename)
        with open(filepath, 'r') as file:
            lines = file.readlines()
            # Son satırdaki son karakteri sil
            lines[-1] = lines[-1][:-1]
        with open(filepath, 'w') as file:
            file.writelines(lines)
            print(f"{filename} güncellendi.")
