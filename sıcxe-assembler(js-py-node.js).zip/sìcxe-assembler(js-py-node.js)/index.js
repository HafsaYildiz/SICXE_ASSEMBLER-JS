const fs = require("fs");
const path = require("path");
const { parseFile } = require("./src/fileManager/fileParser");
const {
  writeSolFile,
  writeProgFile,
} = require("./src/fileManager/fileManager");
const { createSymbolTable } = require("./src/pass1/createSymbolTable");
const generateObjectCode = require("./src/pass2/generateObjectCode");
const {
  generateObjectProgram,
  runCleanUp,
} = require("./src/objectProgram/generateObjectProgram");

const {
  addSymbolTable,
  addProgBlocks,
} = require("./src/objectProgram/generateObjectProgram");

let FILE_NAME = "macros";

const start = () => {
  const parsedLines = parseFile(`./input/${FILE_NAME}.txt`);

  const { symbolTable, parsedLinesWithLocationCounters, progBlocks } =
    createSymbolTable(parsedLines);

  addSymbolTable(symbolTable);
  addProgBlocks(progBlocks);
  const { parsedlines } = generateObjectCode(
    parsedLinesWithLocationCounters,
    symbolTable,
    progBlocks

    
  );

  const solFilePath = `./output/${FILE_NAME}_sol.txt`;
  writeSolFile(solFilePath, parsedlines);
  console.log(`Writing file... ${solFilePath}`);
  console.log(JSON.stringify(parsedlines, null, 2));  // sol dosyasının içeriğini JSON formatında yazdır

  const res = generateObjectProgram(parsedlines);
  runCleanUp();
  console.log(JSON.stringify(res, null, 2));  // obj dosyasının içeriğini JSON formatında yazdır

  const objFilePath = `./output/${FILE_NAME}_obj.txt`;
  writeProgFile(objFilePath, res);
  console.log(`Writing file... ${objFilePath}`);
};

const dir = "./input";
const files = fs.readdirSync(dir);
for (const file of files) {
  FILE_NAME = path.parse(file).name;
  console.log(`Reading file... ./input/${FILE_NAME}.txt`);
  start();
}
