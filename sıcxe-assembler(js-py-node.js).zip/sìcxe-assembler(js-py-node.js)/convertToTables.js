const fs = require('fs');
const path = require('path');

// Girdi ve çıktı dizinleri
const inputDir = './output';
const outputDir = './html_output';

function createHtmlTable(rows, fileName) {
    let tableRows = rows.map(row => {
        const columns = row.trim().split('\t');
        let tableData = columns.map(column => `<td>${column || ''}</td>`).join('\n');
        return `<tr>${tableData}</tr>`;
    }).join('\n');

    const htmlContent = `
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <style>
                table {
                    width: 100%;
                    border-collapse:separate;
                    border-spacing:10px;
                    border: 6px #008080;
                }
                th, td {
                    
                    padding: 6px;
                    color: #000080;
                    font-size: 30pt;
                }
                th {
                    background-color: #00CED1;
                }
                tr {
                    background-color: #00CED1;
                }
                tr:hover {
                    background-color: #6495ED;
                }
            </style>
            <title>${fileName}</title>
        </head>
        <body>
            <h1>${fileName}</h1>
            <table>
                <tr>
                    ${fileName.endsWith('_sol.txt') ? `
                        <th>Location</th>
                        <th>Label</th>
                        <th>Opcode</th>
                        <th>Operand</th>
                        <th>ObjectCode</th>
                        <th>CommentLine</th>` : ''}
                    ${fileName.endsWith('_obj.txt') ? `<th>${tableRows.length > 0 ? 'RECORDS' : ''}</th>` : ''}
                </tr>
                ${tableRows}
            </table>
        </body>
        </html>
    `;

    return htmlContent;
}

// Dosya işlemleri
if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir);
}

fs.readdir(inputDir, (err, files) => {
    if (err) {
        console.error('Girdi dizini okunurken hata oluştu:', err);
        return;
    }

    files.forEach(file => {
        const filePath = path.join(inputDir, file);
        fs.readFile(filePath, 'utf8', (err, fileContent) => {
            if (err) {
                console.error(`${file} dosyası okunurken hata oluştu:`, err);
                return;
            }

            const rows = fileContent.split('\n').filter(line => line.trim() !== '');
            const htmlContent = createHtmlTable(rows, file);
            const outputFilePath = path.join(outputDir, `${file}.html`);
            fs.writeFileSync(outputFilePath, htmlContent, 'utf8');
            console.log(`Oluşturulan HTML dosyası: ${outputFilePath}`);
        });
    });
});